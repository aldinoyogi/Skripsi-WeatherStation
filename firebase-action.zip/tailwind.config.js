/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["stationa.{html,js}", "stationb.{html,js}", "server.js"],
  theme: {
    extend: {},
  },
  plugins: [],
}

